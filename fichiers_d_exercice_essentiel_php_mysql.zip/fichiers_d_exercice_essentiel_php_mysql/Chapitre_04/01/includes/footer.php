
<script type="application/javascript" src="/assets/js/jquery-3.2.1.slim.min.js"></script>
<script type="application/javascript" src="/assets/js/bootstrap.min.js"></script>
</body>
</html>