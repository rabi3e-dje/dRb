<?php
// Commentaire sur une ligne
# Commentaire sur une ligne
/* Commentaire sur
plusieurs lignes
*/
echo 'test';
?>