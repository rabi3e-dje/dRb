
<script type="application/javascript" src="/assets/js/jquery-3.4.1.min.js"></script>
<script type="application/javascript" src="/assets/js/bootstrap.min.js"></script>
<script type="application/javascript" src="/assets/js/jquery-ui.min.js"></script>
<script type="application/javascript" src="/assets/js/script.js"></script>

</body>
</html>