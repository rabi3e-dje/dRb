<?php 

var_dump(abs(-45));

var_dump(ceil(3.1415926));

var_dump(floor(3.1415926));

var_dump(rand(0, 9999));

var_dump(round(3.1415926, 1));