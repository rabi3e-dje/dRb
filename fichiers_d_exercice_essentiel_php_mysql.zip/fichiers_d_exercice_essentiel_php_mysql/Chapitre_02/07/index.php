<?php


echo strlen('abcdef');
echo strtolower('ABCDEF');
echo strtoupper('abcdef');
echo ucfirst('abcdef');
var_dump(trim(' welcome '));
var_dump(substr('abcdef', 2, -2 ));
var_dump(strpos('abcdef', 'abc'));
var_dump(str_replace('abc','def','abcdef'));

