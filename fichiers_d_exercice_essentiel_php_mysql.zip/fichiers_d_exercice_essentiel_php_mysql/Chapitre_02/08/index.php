<?php

$a = 1;
$b = 2;

echo $a + $b;
echo $a . $b;

$a = 1;
$a += 2;

var_dump($a);

$a = 1;
$a .= 2;

var_dump($a);
