<?php

require_once (__DIR__ . '/../../config/database.php');
require_once (__DIR__ . '/../../includes/header.php');

?>

    <main role="main">

        <div class="py-5 bg-light">
            INDEX
        </div>

    </main>


<?php

require_once (__DIR__ . '/../../includes/footer.php');

?>